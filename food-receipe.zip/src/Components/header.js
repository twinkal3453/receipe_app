import React from "react";
import Button from "@material-ui/core/Button";
import TextField from "@material-ui/core/TextField";
import Dialog from "@material-ui/core/Dialog";
import DialogActions from "@material-ui/core/DialogActions";
import DialogContent from "@material-ui/core/DialogContent";
import DialogContentText from "@material-ui/core/DialogContentText";
import DialogTitle from "@material-ui/core/DialogTitle";
import "./css/header.css";

const Header = (props) => {
  const [open, setOpen] = React.useState(false);

  const handleClickOpen = () => {
    setOpen(true);
  };

  const handleClose = () => {
    setOpen(false);
  };

  return (
    <>
      <nav className="navbar navbar-expand-lg navbar-light navbar_total">
        <div className="container-fluid">
          <h3 style={{ color: "white" }}> {props.title}</h3>

          <button
            className="navbar-toggler"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#navbarNav"
            aria-controls="navbarNav"
            aria-expanded="false"
            aria-label="Toggle navigation"
          >
            <span className="navbar-toggler-icon"></span>
          </button>
          <div
            style={{ justifyContent: "flex-end" }}
            className="collapse navbar-collapse"
            id="navbarNav"
          >
            <div className="navs">
              <ul className="navbar-nav">
                <li className="nav-item toggle_menu">
                  <i class="fas fa-list"></i>
                </li>
                <li className="nav-item add_menu">
                  <div>
                    <Button onClick={handleClickOpen}>add receipe</Button>
                    <Dialog
                      style={{ padding: "1rem" }}
                      open={open}
                      aria-labelledby="form-dialog-title"
                    >
                      <DialogTitle id="form-dialog-title">
                        add new receipe
                      </DialogTitle>
                      <DialogContent>
                        <TextField
                          autoFocus
                          margin="dense"
                          id="name"
                          label="Fresh food"
                          type="email"
                          fullWidth
                        />
                        <TextField
                          autoFocus
                          margin="dense"
                          id="name"
                          label="receipe name"
                          type="email"
                          fullWidth
                        />
                        <TextField
                          autoFocus
                          margin="dense"
                          id="name"
                          type="file"
                          fullWidth
                        />
                        <TextField
                          autoFocus
                          margin="dense"
                          id="name"
                          label="Enter ingredients, saperated by comma"
                          type="email"
                          fullWidth
                        />
                      </DialogContent>
                      <DialogActions>
                        <Button
                          style={{ background: "green", color: "white" }}
                          onClick={handleClose}
                          color="primary"
                        >
                          add
                        </Button>
                      </DialogActions>
                    </Dialog>
                  </div>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </nav>
    </>
  );
};
export default Header;

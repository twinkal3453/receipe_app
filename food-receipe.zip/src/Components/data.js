import image1 from "../assets/food1.jpg";
import image2 from "../assets/food2.jpg";
import image3 from "../assets/food3.jpg";

export const Foods = [
  {
    images: image1,
    titles: "Loaded Gaucamole toast",
  },
  {
    images: image2,
    titles: "Loaded Gaucamole toast2",
  },
  {
    images: image3,
    titles: "Loaded Gaucamole toast3",
  },
];

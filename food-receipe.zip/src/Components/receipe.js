import React from "react";
import "./css/card.css";
import { Foods } from "./data";

// material ui
import { makeStyles } from "@material-ui/core/styles";
import Card from "@material-ui/core/Card";
import CardActionArea from "@material-ui/core/CardActionArea";
import CardContent from "@material-ui/core/CardContent";
import CardMedia from "@material-ui/core/CardMedia";
import Typography from "@material-ui/core/Typography";

const useStyles = makeStyles({
  root: {
    maxWidth: 345,
  },
});

const Receipe = () => {
  const classes = useStyles();
  return (
    <>
      <div className="container grid_main">
        {Foods.map((item, index) => {
          return (
            <Card className={classes.root}>
              <CardActionArea>
                <CardMedia
                  component="img"
                  alt="Contemplative Reptile"
                  height="140"
                  image={item.images}
                  title="Receipe"
                />
                <CardContent>
                  <Typography gutterBottom variant="h5" component="h2">
                    {item.titles}
                  </Typography>
                </CardContent>
              </CardActionArea>
            </Card>
          );
        })}
      </div>
    </>
  );
};

export default Receipe;

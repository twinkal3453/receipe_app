import Header from "./Components/header";
import Receipe from "./Components/receipe";
function App() {
  return (
    <>
      <div className="head">
        <Header title="receipe-box" />
        <Receipe />
      </div>
    </>
  );
}

export default App;
